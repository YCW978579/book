import React,{ Component } from 'react'
import localstorage from '../common/local'
import '../assets/css/index.css';

export default class Todolist extends Component{
    constructor(){
        super()
        this.state={
            list:[]
        }
    }
    addList=(ev)=>{
        if(ev.keyCode == 13){
            let item ={
                title:this.refs.name.value,
                checked:false
            }
            this.refs.name.value=""
            let newList = this.state.list
            newList.push(item)
            this.setState({
                list:newList
            })
            // localstorage.save('todolist',this.state.list)
            localStorage.setItem('todolist',JSON.stringify(this.state.list))
        }
    }
    componentDidMount(){
        this.setState({
            list:JSON.parse(localStorage.getItem('todolist'))
            // list:localstorage.get('todolist')
        })
    }
    changeState=(key)=>{
        let newList = this.state.list
        newList[key].checked = !newList[key].checked
        this.setState({
            list:newList
        })
        localStorage.setItem('todolist',JSON.stringify(this.state.list))
    }
    del=(key)=>{
        let newList=this.state.list
        newList.splice(key,1)
        this.setState({
            list:newList
        })
        localStorage.setItem('todolist',JSON.stringify(this.state.list))
    }
    fix=()=>{

    }
    render(){
        return(
            <div>
                <div className="page-top">
                    <div className="page-content">
                        <h2>任务计划列表</h2>
                    </div>
                </div>
           <div className="main">
              <h3 className="big-title">添加任务：</h3>
                <input type="text"  className="task-input" onKeyUp={this.addList} ref="name" placeholder="例如：吃饭睡觉打豆豆；    提示：+回车即可添加任务"/>
                <div>
                    
                    <ul className="todo-list">
                      <li>未完成</li>
                        {
                            this.state.list.map((val,key)=>{
                                if(!val.checked){
                                    return(
                                        <li key={key} className="todo" onDoubleClick={this.fix.bind(this.key)}>
                                          <input className="toggle" type="checkbox" checked={val.checked} onChange={this.changeState.bind(this,key)}/>
                                          <span>{val.title}</span>
                                          -----<button onClick={this.del.bind(this.key)}>删除</button>
                                       </li> 
                                    )
                                }
                            })
                        }
                    </ul>
                    <h3 className="big-title">任务列表：</h3>
                    <div className="tasks">
                    <span className="no-task-tip">还没有添加任何任务</span>
                    <ul className="todo-list">
                      
                        {
                            this.state.list.map((val,key)=>{
                                if(val.checked){
                                    return(
                                        <li key={key} className="todo">
                                        <div>
                                          <input className="toggle" type="checkbox" checked={val.checked} onChange={this.changeState.bind(this,key)}/>
                                          <span>{val.title}</span>
                                          -----<button className="destroy" onClick={this.del.bind(this.key)}></button>
                                          </div>
                                       </li> 
                                    )
                                }
                            })
                        }
                    </ul>
                 </div>
                </div>
              </div>
                
            </div>
        )
    }
}